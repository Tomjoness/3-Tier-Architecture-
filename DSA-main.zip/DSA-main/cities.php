<!DOCTYPE html>

<html>
 <head>
  <title>Cities</title>
  <body style="background-color:rgb(211, 228, 231);"> 
  <h1 style="font-size:50px;">Cities</h1>
 </head>

<body>
 
  <?php include 'C:\xampp\htdocs\Cities\B_flicker.php'; ?> 
  <h2> Weather </h2>
  <?php include 'C:\xampp\htdocs\Cities\wea.php'; ?> 
  <?php include 'C:\xampp\htdocs\Cities\map_B.php'; ?> 
  

  <p>Wikipedia Page tom</p>
  <a href="https://en.wikipedia.org/wiki/Birmingham">This is a link</a>
  


  <?php include 'C:\xampp\htdocs\Cities\C_flicker.php'; ?>
  <h2> Weather </h2>
  <?php include 'C:\xampp\htdocs\Cities\wea1.php'; ?>
  <?php include 'C:\xampp\htdocs\Cities\map_C.php'; ?>
   

  <p>Wikipedia page:</p>
  <a href="https://en.wikipedia.org/wiki/Chicago">This is a link</a>



</body>
</html>
