<?php

$host = '127.0.0.1';
$db   = 'twin cities';
$user = 'root';
$pass = '';

$weather_key = "7086ad7c2703284caef1e08c1606b2e1";

$flicker_key = 'bd4d0cbd5d7271f3929ed1449d0ba636';

$map_key = "AIzaSyD-OpWo0XwXNqP2ZciympymQRnlh2KYICI ";